import { Link, useLocation } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import Icon from './Icon'

function Header() {
  const { cartCount } = useCart()
  const location = useLocation()
  const isActive = (path) => location.pathname === path

  return (
    <header className="header">
      <div className="header-inner">
        <Link to="/" className="header-brand">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
          </svg>
          خيوط
        </Link>
        <nav className="header-nav">
          <Link to="/" className={isActive('/') ? 'active' : ''}>الرئيسية</Link>
          <Link to="/shop" className={isActive('/shop') ? 'active' : ''}>المتجر</Link>
          <Link to="/dashboard" className={isActive('/dashboard') ? 'active' : ''}>لوحة التحكم</Link>
        </nav>
        <div className="header-actions">
          <button className="header-btn">
            <Icon name="search" size={18} />
          </button>
          <button className="header-btn">
            <Icon name="profile" size={18} />
          </button>
          <Link to="/cart" className={`header-btn ${isActive('/cart') ? 'active' : ''}`}>
            <Icon name="cart" size={18} />
            {cartCount > 0 && <span className="badge">{cartCount}</span>}
          </Link>
          <button className="theme-toggle">
            <span></span>
          </button>
        </div>
      </div>
    </header>
  )
}

export default Header
