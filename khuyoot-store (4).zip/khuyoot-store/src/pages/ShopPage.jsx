import { useState } from 'react'
import { products, categories } from '../data/products'
import ProductCard from '../components/ProductCard'
import Icon from '../components/Icon'

function ShopPage() {
  const [activeCategory, setActiveCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')

  const filtered = products.filter(p => {
    const matchCategory = activeCategory === 'all' || p.category === activeCategory
    const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        p.category.toLowerCase().includes(searchQuery.toLowerCase())
    return matchCategory && matchSearch
  })

  return (
    <div className="fade-in">
      <div style={{ padding: '0 32px 16px' }}>
        <h1 className="section-title" style={{ marginBottom: 16 }}>المتجر</h1>
        <div style={{ position: 'relative', maxWidth: 400, marginBottom: 24 }}>
          <input
            type="text"
            placeholder="ابحث عن منتج..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              width: '100%', padding: '10px 14px 10px 40px', border: '1px solid var(--kh-border)',
              borderRadius: 'var(--k-radius)', background: 'var(--kh-surface-2)', color: 'var(--kh-text)',
              fontFamily: 'inherit', fontSize: '0.9rem'
            }}
          />
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--kh-text-muted)' }}>
            <Icon name="search" size={18} />
          </span>
        </div>
      </div>

      <div className="nav-pills">
        {categories.map(cat => (
          <button
            key={cat.id}
            className={`nav-pill ${activeCategory === cat.id ? 'active' : ''}`}
            onClick={() => setActiveCategory(cat.id)}
          >
            <Icon name={cat.icon} size={14} />
            {cat.name}
          </button>
        ))}
      </div>

      <div style={{ padding: '24px 32px' }}>
        <div style={{ color: 'var(--kh-text-muted)', fontSize: '0.85rem', marginBottom: 16 }}>
          {filtered.length} منتج
        </div>
        <div className="product-grid">
          {filtered.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
        {filtered.length === 0 && (
          <div className="empty-state">
            <div className="icon">
              <Icon name="search" size={64} />
            </div>
            <h3>لا توجد منتجات</h3>
            <p>جرب البحث بكلمات مختلفة</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default ShopPage
