import { Link } from 'react-router-dom'
import Icon from '../components/Icon'

function NotFoundPage() {
  return (
    <div className="empty-state fade-in" style={{ padding: '120px 20px' }}>
      <div className="icon" style={{ color: 'var(--kh-gold)', marginBottom: 24 }}>
        <Icon name="error" size={80} />
      </div>
      <h1 style={{ fontSize: '3rem', fontWeight: 800, color: 'var(--kh-gold)', marginBottom: 16 }}>404</h1>
      <h3 style={{ fontSize: '1.3rem', marginBottom: 12 }}>الصفحة غير موجودة</h3>
      <p style={{ color: 'var(--kh-text-muted)', marginBottom: 24 }}>الصفحة التي تبحث عنها غير متوفرة</p>
      <Link to="/" className="btn-cta">
        <Icon name="home" size={18} />
        العودة للرئيسية
      </Link>
    </div>
  )
}

export default NotFoundPage
