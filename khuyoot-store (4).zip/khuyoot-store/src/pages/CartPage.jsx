import { Link } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { showToast } from '../components/Toast'
import Icon from '../components/Icon'

function CartPage() {
  const { cart, removeFromCart, updateQty, cartTotal, clearCart } = useCart()

  const handleRemove = (id, size, name) => {
    removeFromCart(id, size)
    showToast(`تم حذف ${name} من السلة`, 'info')
  }

  if (cart.length === 0) {
    return (
      <div className="cart-page fade-in">
        <div className="empty-state">
          <div className="icon">
            <Icon name="cart" size={64} />
          </div>
          <h3>السلة فارغة</h3>
          <p>استكشف منتجاتنا وأضف ما تحب</p>
          <Link to="/shop" className="btn-cta" style={{ marginTop: 16, display: 'inline-block' }}>
            تسوق الآن
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="cart-page fade-in">
      <div className="section-header">
        <h1 className="section-title">سلة التسوق</h1>
        <button className="btn-ghost-kh" onClick={clearCart}>
          <Icon name="delete" size={16} />
          إفراغ السلة
        </button>
      </div>

      {cart.map(item => (
        <div key={`${item.id}-${item.size}`} className="cart-item">
          <div className="cart-item-img">
            <img src={item.images[0]} alt={item.name} />
          </div>
          <div className="cart-item-info">
            <div className="cart-item-name">{item.name}</div>
            <div style={{ fontSize: '0.8rem', color: 'var(--kh-text-muted)' }}>
              المقاس: {item.size}
            </div>
            <div className="cart-item-price">{item.price} ر.س</div>
          </div>
          <div className="cart-item-actions">
            <div className="qty-selector">
              <button className="qty-btn" onClick={() => updateQty(item.id, item.size, item.qty - 1)}>-</button>
              <span className="qty-value">{item.qty}</span>
              <button className="qty-btn" onClick={() => updateQty(item.id, item.size, item.qty + 1)}>+</button>
            </div>
            <button className="cart-item-remove" onClick={() => handleRemove(item.id, item.size, item.name)}>
              <Icon name="delete" size={18} />
            </button>
          </div>
        </div>
      ))}

      <div className="cart-summary">
        <div className="summary-row">
          <span>المجموع الفرعي</span>
          <span>{cartTotal} ر.س</span>
        </div>
        <div className="summary-row">
          <span>الشحن</span>
          <span>{cartTotal >= 200 ? 'مجاني' : '25 ر.س'}</span>
        </div>
        <div className="summary-row total">
          <span>الإجمالي</span>
          <span>{cartTotal >= 200 ? cartTotal : cartTotal + 25} ر.س</span>
        </div>
        <Link to="/checkout" className="btn-primary-kh" style={{ width: '100%', justifyContent: 'center', marginTop: 16 }}>
          إتمام الطلب
        </Link>
      </div>
    </div>
  )
}

export default CartPage
