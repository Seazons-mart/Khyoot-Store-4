import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { showToast } from '../components/Toast'
import Icon from '../components/Icon'

function CheckoutPage() {
  const { cart, cartTotal, clearCart } = useCart()
  const navigate = useNavigate()
  const [paymentMethod, setPaymentMethod] = useState('cod')
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    notes: ''
  })

  const shipping = cartTotal >= 200 ? 0 : 25
  const total = cartTotal + shipping

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!formData.name || !formData.phone || !formData.address) {
      showToast('يرجى ملء جميع الحقول المطلوبة', 'error')
      return
    }
    showToast('تم تأكيد طلبك بنجاح!', 'success')
    clearCart()
    navigate('/')
  }

  if (cart.length === 0) {
    return (
      <div className="checkout-page fade-in">
        <div className="empty-state">
          <h3>لا توجد منتجات للطلب</h3>
          <Link to="/shop" className="btn-cta" style={{ marginTop: 16, display: 'inline-block' }}>
            العودة للمتجر
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="checkout-page fade-in">
      <div style={{ paddingBottom: 16 }}>
        <Link to="/cart" style={{ color: 'var(--kh-text-muted)', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: 6 }}>
          <Icon name="right" size={16} />
          العودة للسلة
        </Link>
      </div>
      <h1 className="section-title" style={{ marginBottom: 24 }}>إتمام الطلب</h1>

      <form onSubmit={handleSubmit}>
        <div style={{ background: 'var(--kh-surface-1)', border: '1px solid var(--kh-border)', borderRadius: 'var(--k-radius-lg)', padding: 24, marginBottom: 24 }}>
          <h2 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 16 }}>معلومات التوصيل</h2>
          <div className="product-form">
            <div className="form-group">
              <label className="form-label">الاسم الكامل *</label>
              <input type="text" name="name" className="form-field" placeholder="محمد أحمد" value={formData.name} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label className="form-label">رقم الجوال *</label>
              <input type="tel" name="phone" className="form-field" placeholder="05xxxxxxxx" value={formData.phone} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label className="form-label">البريد الإلكتروني</label>
              <input type="email" name="email" className="form-field" placeholder="example@email.com" value={formData.email} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label className="form-label">المدينة *</label>
              <input type="text" name="city" className="form-field" placeholder="الرياض" value={formData.city} onChange={handleChange} required />
            </div>
            <div className="form-group full">
              <label className="form-label">العنوان *</label>
              <input type="text" name="address" className="form-field" placeholder="حي النخيل، شارع العليا" value={formData.address} onChange={handleChange} required />
            </div>
            <div className="form-group full">
              <label className="form-label">ملاحظات</label>
              <textarea name="notes" className="form-field form-textarea" placeholder="أي ملاحظات خاصة بالطلب..." value={formData.notes} onChange={handleChange} />
            </div>
          </div>
        </div>

        <div style={{ background: 'var(--kh-surface-1)', border: '1px solid var(--kh-border)', borderRadius: 'var(--k-radius-lg)', padding: 24, marginBottom: 24 }}>
          <h2 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 16 }}>طريقة الدفع</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <label className={`payment-option ${paymentMethod === 'cod' ? 'active' : ''}`}>
              <input type="radio" name="payment" value="cod" checked={paymentMethod === 'cod'} onChange={() => setPaymentMethod('cod')} />
              <Icon name="document" size={20} />
              الدفع عند الاستلام
            </label>
            <label className={`payment-option ${paymentMethod === 'wallet' ? 'active' : ''}`}>
              <input type="radio" name="payment" value="wallet" checked={paymentMethod === 'wallet'} onChange={() => setPaymentMethod('wallet')} />
              <Icon name="profile" size={20} />
              محفظة إلكترونية
            </label>
          </div>
        </div>

        <div style={{ background: 'var(--kh-surface-1)', border: '1px solid var(--kh-border)', borderRadius: 'var(--k-radius-lg)', padding: 24 }}>
          <h2 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 16 }}>ملخص الطلب</h2>
          {cart.map(item => (
            <div key={`${item.id}-${item.size}`} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--kh-border)', fontSize: '0.9rem' }}>
              <span>{item.name} × {item.qty} (مقاس {item.size})</span>
              <span>{item.price * item.qty} ر.س</span>
            </div>
          ))}
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--kh-border)', marginTop: 8 }}>
            <span style={{ color: 'var(--kh-text-sec)' }}>المجموع الفرعي</span>
            <span>{cartTotal} ر.س</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--kh-border)' }}>
            <span style={{ color: 'var(--kh-text-sec)' }}>الشحن</span>
            <span>{shipping === 0 ? 'مجاني' : `${shipping} ر.س`}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '16px 0 0', fontSize: '1.2rem', fontWeight: 800 }}>
            <span>الإجمالي</span>
            <span style={{ color: 'var(--kh-gold)' }}>{total} ر.س</span>
          </div>
          <button type="submit" className="btn-primary-kh" style={{ width: '100%', justifyContent: 'center', marginTop: 20 }}>
            <Icon name="check" size={20} />
            تأكيد الطلب
          </button>
        </div>
      </form>
    </div>
  )
}

export default CheckoutPage
