import { Link } from 'react-router-dom'
import { products } from '../data/products'
import ProductCard from '../components/ProductCard'
import Icon from '../components/Icon'

function HomePage() {
  const featured = products.slice(0, 6)
  const newArrivals = products.slice(6, 12)

  return (
    <div className="fade-in">
      <section className="hero">
        <div className="hero-content">
          <div className="hero-eyebrow">أزياء عربية فاخرة</div>
          <h1>خيوط Khuyoot</h1>
          <p>اكتشف تشكيلتنا الفريدة من الأزياء العربية العصرية. تصاميم أنيقة تجمع بين الأصالة والمعاصرة.</p>
          <div className="hero-actions">
            <Link to="/shop" className="btn-cta">تسوق الآن</Link>
            <Link to="/shop" className="btn-ghost-kh">اكتشف المزيد</Link>
          </div>
        </div>
      </section>

      <section className="trust-row">
        <div className="trust-item">
          <div className="trust-icon">🚚</div>
          <div>
            <div className="trust-title">شحن مجاني</div>
            <div className="trust-desc">للطلبات فوق 200 ر.س</div>
          </div>
        </div>
        <div className="trust-item">
          <div className="trust-icon">↩️</div>
          <div>
            <div className="trust-title">إرجاع سهل</div>
            <div className="trust-desc">خلال 14 يوم</div>
          </div>
        </div>
        <div className="trust-item">
          <div className="trust-icon">🔒</div>
          <div>
            <div className="trust-title">دفع آمن</div>
            <div className="trust-desc">تشفير SSL</div>
          </div>
        </div>
        <div className="trust-item">
          <div className="trust-icon">⭐</div>
          <div>
            <div className="trust-title">جودة مضمونة</div>
            <div className="trust-desc">أقمشة فاخرة</div>
          </div>
        </div>
      </section>

      <section style={{ padding: '0 32px 48px' }}>
        <div className="section-header">
          <h2 className="section-title">منتجات مميزة</h2>
          <Link to="/shop" className="section-link">
            عرض الكل <Icon name="left" size={16} />
          </Link>
        </div>
        <div className="product-grid">
          {featured.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section style={{ padding: '0 32px 48px' }}>
        <div className="section-header">
          <h2 className="section-title">وصل حديثاً</h2>
          <Link to="/shop" className="section-link">
            عرض الكل <Icon name="left" size={16} />
          </Link>
        </div>
        <div className="product-grid">
          {newArrivals.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
    </div>
  )
}

export default HomePage
