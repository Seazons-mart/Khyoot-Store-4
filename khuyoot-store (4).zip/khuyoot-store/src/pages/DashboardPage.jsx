import { useState } from 'react'
import { products, orders } from '../data/products'
import Icon from '../components/Icon'

function DashboardPage() {
  const [activeTab, setActiveTab] = useState('overview')
  const [editingProduct, setEditingProduct] = useState(null)
  const [showAddModal, setShowAddModal] = useState(false)

  const stats = [
    { label: 'إجمالي المبيعات', value: '12,450', change: '+12%', up: true, icon: 'histogram', color: 'gold' },
    { label: 'الطلبات', value: '156', change: '+8%', up: true, icon: 'list', color: 'emerald' },
    { label: 'المنتجات', value: products.length.toString(), change: '+3', up: true, icon: 'catalog', color: 'bronze' },
    { label: 'العملاء', value: '89', change: '+15%', up: true, icon: 'group', color: 'purple' },
  ]

  const salesData = [
    { label: 'يناير', value: 3200, color: '#c9a227' },
    { label: 'فبراير', value: 4100, color: '#c9a227' },
    { label: 'مارس', value: 3800, color: '#c9a227' },
    { label: 'أبريل', value: 5200, color: '#c9a227' },
    { label: 'مايو', value: 4800, color: '#c9a227' },
    { label: 'يونيو', value: 6100, color: '#c9a227' },
    { label: 'يوليو', value: 5500, color: '#c9a227' },
  ]

  const maxSales = Math.max(...salesData.map(d => d.value))

  const getStatusClass = (status) => {
    const map = {
      completed: 'status-completed',
      pending: 'status-pending',
      shipping: 'status-shipping',
      cancelled: 'status-cancelled'
    }
    return map[status] || 'status-pending'
  }

  const getStatusLabel = (status) => {
    const map = {
      completed: 'مكتمل',
      pending: 'قيد الانتظار',
      shipping: 'قيد الشحن',
      cancelled: 'ملغي'
    }
    return map[status] || status
  }

  return (
    <div className="dashboard-grid fade-in">
      <aside className="dashboard-sidebar">
        <div style={{ padding: '8px 0', borderBottom: '1px solid var(--kh-border)', marginBottom: 12 }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--kh-text-muted)', fontWeight: 600, letterSpacing: '1px' }}>لوحة التحكم</div>
        </div>
        {[
          { id: 'overview', label: 'نظرة عامة', icon: 'histogram' },
          { id: 'products', label: 'المنتجات', icon: 'catalog' },
          { id: 'orders', label: 'الطلبات', icon: 'list' },
          { id: 'customers', label: 'العملاء', icon: 'group' },
          { id: 'settings', label: 'الإعدادات', icon: 'setting' },
        ].map(item => (
          <button
            key={item.id}
            className={`sidebar-item ${activeTab === item.id ? 'active' : ''}`}
            onClick={() => setActiveTab(item.id)}
          >
            <Icon name={item.icon} size={18} />
            {item.label}
          </button>
        ))}
      </aside>

      <div className="dashboard-content">
        {activeTab === 'overview' && (
          <div>
            <h1 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: 24 }}>نظرة عامة</h1>
            <div className="stats-grid">
              {stats.map((stat, i) => (
                <div key={i} className="stat-card">
                  <div className={`stat-icon ${stat.color}`}>
                    <Icon name={stat.icon} size={22} />
                  </div>
                  <div className="stat-value">{stat.value}</div>
                  <div className="stat-label">{stat.label}</div>
                  <div className={`stat-change ${stat.up ? 'up' : 'down'}`}>
                    {stat.up ? '↑' : '↓'} {stat.change}
                  </div>
                </div>
              ))}
            </div>

            <div className="chart-container">
              <div className="chart-title">المبيعات الشهرية</div>
              <div className="bar-chart">
                {salesData.map((item, i) => (
                  <div key={i} className="bar-item">
                    <div className="bar-value">{item.value.toLocaleString()}</div>
                    <div
                      className="bar"
                      style={{
                        height: `${(item.value / maxSales) * 100}%`,
                        background: item.color,
                        minHeight: 20
                      }}
                    />
                    <div className="bar-label">{item.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="chart-container">
              <div className="chart-title">آخر الطلبات</div>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>رقم الطلب</th>
                    <th>العميل</th>
                    <th>التاريخ</th>
                    <th>المبلغ</th>
                    <th>الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.slice(0, 5).map(order => (
                    <tr key={order.id}>
                      <td>{order.id}</td>
                      <td>{order.customer}</td>
                      <td>{order.date}</td>
                      <td>{order.total} ر.س</td>
                      <td><span className={`status-badge ${getStatusClass(order.status)}`}>{getStatusLabel(order.status)}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
              <h1 style={{ fontSize: '1.3rem', fontWeight: 800 }}>المنتجات</h1>
              <button className="btn-primary-kh" onClick={() => setShowAddModal(true)}>
                <Icon name="add" size={18} />
                إضافة منتج
              </button>
            </div>
            <table className="data-table">
              <thead>
                <tr>
                  <th>المنتج</th>
                  <th>التصنيف</th>
                  <th>السعر</th>
                  <th>المخزون</th>
                  <th>التقييم</th>
                  <th>الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {products.map(product => (
                  <tr key={product.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <img src={product.images[0]} alt={product.name} style={{ width: 40, height: 40, borderRadius: 8, objectFit: 'cover' }} />
                        <span>{product.name}</span>
                      </div>
                    </td>
                    <td>{product.category}</td>
                    <td>{product.price} ر.س</td>
                    <td>{product.inStock ? 'متوفر' : 'نفذ'}</td>
                    <td>{product.rating} ★</td>
                    <td>
                      <div className="table-actions">
                        <button className="table-btn" onClick={() => setEditingProduct(product)}>
                          <Icon name="edit" size={16} />
                        </button>
                        <button className="table-btn danger">
                          <Icon name="delete" size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'orders' && (
          <div>
            <h1 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: 24 }}>الطلبات</h1>
            <table className="data-table">
              <thead>
                <tr>
                  <th>رقم الطلب</th>
                  <th>العميل</th>
                  <th>التاريخ</th>
                  <th>المنتجات</th>
                  <th>المبلغ</th>
                  <th>الحالة</th>
                  <th>الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(order => (
                  <tr key={order.id}>
                    <td>{order.id}</td>
                    <td>{order.customer}</td>
                    <td>{order.date}</td>
                    <td>{order.items}</td>
                    <td>{order.total} ر.س</td>
                    <td><span className={`status-badge ${getStatusClass(order.status)}`}>{getStatusLabel(order.status)}</span></td>
                    <td>
                      <div className="table-actions">
                        <button className="table-btn">
                          <Icon name="viewAll" size={16} />
                        </button>
                        <button className="table-btn">
                          <Icon name="edit" size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'customers' && (
          <div>
            <h1 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: 24 }}>العملاء</h1>
            <div className="empty-state">
              <div className="icon"><Icon name="group" size={64} /></div>
              <h3>قريباً</h3>
              <p>سيتم إضافة إدارة العملاء قريباً</p>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div>
            <h1 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: 24 }}>الإعدادات</h1>
            <div className="empty-state">
              <div className="icon"><Icon name="setting" size={64} /></div>
              <h3>قريباً</h3>
              <p>سيتم إضافة الإعدادات قريباً</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default DashboardPage
