import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { products } from '../data/products'
import { useCart } from '../context/CartContext'
import { showToast } from '../components/Toast'
import Icon from '../components/Icon'

function ProductDetailPage() {
  const { id } = useParams()
  const product = products.find(p => p.id === parseInt(id))
  const { addToCart } = useCart()
  const [selectedSize, setSelectedSize] = useState(product?.sizes[0] || '')
  const [selectedImage, setSelectedImage] = useState(0)
  const [qty, setQty] = useState(1)

  if (!product) {
    return (
      <div className="empty-state">
        <h3>المنتج غير موجود</h3>
        <Link to="/shop" className="btn-cta" style={{ marginTop: 16, display: 'inline-block' }}>
          العودة للمتجر
        </Link>
      </div>
    )
  }

  const handleAddToCart = () => {
    addToCart(product, qty, selectedSize)
    showToast(`تمت إضافة ${product.name} للسلة`, 'success')
  }

  return (
    <div className="fade-in">
      <div style={{ padding: '0 32px 24px' }}>
        <Link to="/shop" style={{ color: 'var(--kh-text-muted)', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: 6 }}>
          <Icon name="right" size={16} />
          العودة للمتجر
        </Link>
      </div>
      <div className="product-detail" style={{ padding: '0 32px' }}>
        <div className="product-gallery">
          <div className="product-detail-img">
            <img src={product.images[selectedImage]} alt={product.name} />
          </div>
          {product.images.length > 1 && (
            <div className="gallery-thumbs">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  className={`gallery-thumb ${selectedImage === i ? 'active' : ''}`}
                  onClick={() => setSelectedImage(i)}
                >
                  <img src={img} alt={`${product.name} - ${i + 1}`} />
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="product-detail-info">
          <div className="product-detail-category">{product.category}</div>
          <h1 className="product-detail-name">{product.name}</h1>
          <div className="product-rating">
            <span className="stars">
              {'★'.repeat(Math.floor(product.rating))}
              {'☆'.repeat(5 - Math.floor(product.rating))}
            </span>
            <span className="rating-count">({product.reviews} تقييم)</span>
          </div>
          <p className="product-detail-desc">{product.description}</p>

          <div>
            <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--kh-text-sec)', marginBottom: 10 }}>المقاس</div>
            <div className="size-selector">
              {product.sizes.map(size => (
                <button
                  key={size}
                  className={`size-btn ${selectedSize === size ? 'active' : ''}`}
                  onClick={() => setSelectedSize(size)}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div className="product-detail-price-row">
            <span className="product-detail-price">{product.price} ر.س</span>
            {product.oldPrice && (
              <span className="product-detail-old">{product.oldPrice} ر.س</span>
            )}
          </div>

          <div className="product-detail-actions">
            <div className="qty-selector">
              <button className="qty-btn" onClick={() => setQty(Math.max(1, qty - 1))}>-</button>
              <span className="qty-value">{qty}</span>
              <button className="qty-btn" onClick={() => setQty(qty + 1)}>+</button>
            </div>
            <button className="btn-primary-kh" onClick={handleAddToCart}>
              <Icon name="cart" size={20} />
              أضف للسلة
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ProductDetailPage
