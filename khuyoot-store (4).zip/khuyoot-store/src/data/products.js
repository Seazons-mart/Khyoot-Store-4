export const products = [
  {
    id: 1,
    name: "تيشيرت SWO رمادي",
    category: "تيشيرتات",
    tier: "vip",
    price: 89,
    oldPrice: 120,
    rating: 4.8,
    reviews: 124,
    description: "تيشيرت SWO رمادي فاخر بتصميم عصري أنيق. قماش قطني 100% عالي الجودة، مقاوم للتجعد، مناسب للارتداء اليومي والمناسبات الكاجوال.",
    images: [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&h=800&fit=crop"
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["رمادي", "أسود", "أبيض"],
    badge: "VIP",
    inStock: true
  },
  {
    id: 2,
    name: "تيشيرت STWS أزرق",
    category: "تيشيرتات",
    tier: "premium",
    price: 75,
    oldPrice: 95,
    rating: 4.6,
    reviews: 89,
    description: "تيشيرت STWS أزرق بتصميم أمامي وخلفي مميز. قماش ناعم ومريح، يمنحك إطلالة عصرية وجذابة.",
    images: [
      "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1581655353564-df123a1eb820?w=600&h=800&fit=crop"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: ["أزرق", "كحلي", "أسود"],
    badge: "Premium",
    inStock: true
  },
  {
    id: 3,
    name: "تيشيرت Summer Rhythms أبيض",
    category: "تيشيرتات",
    tier: "classic",
    price: 59,
    oldPrice: null,
    rating: 4.5,
    reviews: 67,
    description: "تيشيرت Summer Rhythms أبيض بتصميم صيفي منعش. قماش خفيف ومناسب للأجواء الحارة.",
    images: [
      "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&h=800&fit=crop"
    ],
    sizes: ["M", "L", "XL"],
    colors: ["أبيض", "بيج"],
    badge: null,
    inStock: true
  },
  {
    id: 4,
    name: "بولو أبيض كلاسيكي",
    category: "بولو",
    tier: "premium",
    price: 99,
    oldPrice: 130,
    rating: 4.7,
    reviews: 156,
    description: "بولو أبيض كلاسيكي بياقة أنيقة وأزرار خشبية. قماش بيكيه فاخر، مثالي للمناسبات الرسمية والكاجوال.",
    images: [
      "https://images.unsplash.com/photo-1625910513413-5fc4e5e6727e?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1586363104862-3a5e2ab60d8c?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=600&h=800&fit=crop"
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["أبيض", "كحلي", "أسود", "رمادي"],
    badge: "Premium",
    inStock: true
  },
  {
    id: 5,
    name: "شورت رمادي كاجوال",
    category: "شورتات",
    tier: "classic",
    price: 69,
    oldPrice: 85,
    rating: 4.4,
    reviews: 43,
    description: "شورت رمادي كاجوال بتصميم عملي وأنيق. قماش قطني مريح مع جيوب جانبية.",
    images: [
      "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=600&h=800&fit=crop"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: ["رمادي", "أسود", "كحلي"],
    badge: null,
    inStock: true
  },
  {
    id: 6,
    name: "شورت أسود رياضي",
    category: "شورتات",
    tier: "premium",
    price: 79,
    oldPrice: null,
    rating: 4.6,
    reviews: 78,
    description: "شورت أسود رياضي بتصميم عصري. قماش مرن ومريح، مناسب للرياضة والخروجات.",
    images: [
      "https://images.unsplash.com/photo-1562183241-b937e95585b6?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=600&h=800&fit=crop"
    ],
    sizes: ["M", "L", "XL", "XXL"],
    colors: ["أسود", "رمادي"],
    badge: "Premium",
    inStock: true
  },
  {
    id: 7,
    name: "بنطلون جينز فاتح",
    category: "بناطيل",
    tier: "vip",
    price: 149,
    oldPrice: 189,
    rating: 4.9,
    reviews: 203,
    description: "بنطلون جينز فاتح كلاسيكي بتصميم عصري. قماش دينم فاخر، مقاوم للبهتان، مناسب لجميع المناسبات.",
    images: [
      "https://images.unsplash.com/photo-1542272604-787c38356a74?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=600&h=800&fit=crop"
    ],
    sizes: ["30", "32", "34", "36", "38"],
    colors: ["فاتح", "غامق", "أسود"],
    badge: "VIP",
    inStock: true
  },
  {
    id: 8,
    name: "إيسوفمان Nike 11 لون",
    category: "إيسوفمان",
    tier: "premium",
    price: 129,
    oldPrice: 160,
    rating: 4.7,
    reviews: 312,
    description: "إيسوفمان Nike بـ 11 لون مختلف. قماش نايلون عالي الجودة، مقاوم للماء، مناسب للرياضة والتنزه.",
    images: [
      "https://images.unsplash.com/photo-1517438476312-10d79c077509?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=600&h=800&fit=crop"
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["أزرق", "أسود", "كحلي", "أبيض", "أخضر", "رمادي"],
    badge: "Premium",
    inStock: true
  },
  {
    id: 9,
    name: "بولو كتان بيج",
    category: "بولو",
    tier: "classic",
    price: 85,
    oldPrice: null,
    rating: 4.3,
    reviews: 56,
    description: "بولو كتان بيج محبوك بتصميم كلاسيكي أنيق. قماش كتان طبيعي، مناسب للصيف.",
    images: [
      "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1625910513413-5fc4e5e6727e?w=600&h=800&fit=crop"
    ],
    sizes: ["M", "L", "XL"],
    colors: ["بيج", "أبيض", "كحلي"],
    badge: null,
    inStock: true
  },
  {
    id: 10,
    name: "سويت شيرت أزرق",
    category: "سويت شيرت",
    tier: "premium",
    price: 119,
    oldPrice: 145,
    rating: 4.6,
    reviews: 94,
    description: "سويت شيرت أزرق محبوك سميك كاجوال. قماش ناعم ودافئ، مثالي للأجواء الباردة.",
    images: [
      "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1578587018452-892b6fd8dbb4?w=600&h=800&fit=crop"
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["أزرق", "أسود", "رمادي", "كحلي"],
    badge: "Premium",
    inStock: true
  },
  {
    id: 11,
    name: "فيست أبيض محبوك",
    category: "فيست",
    tier: "classic",
    price: 95,
    oldPrice: 115,
    rating: 4.5,
    reviews: 71,
    description: "فيست أبيض محبوك بياقة بولو. تصميم أنيق وعصري، مناسب للطبقات.",
    images: [
      "https://images.unsplash.com/photo-1434389677669-e08b4fcb3b5b?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1578587018452-892b6fd8dbb4?w=600&h=800&fit=crop"
    ],
    sizes: ["M", "L", "XL"],
    colors: ["أبيض", "بيج", "رمادي"],
    badge: null,
    inStock: true
  },
  {
    id: 12,
    name: "هاي نيك أبيض",
    category: "هاي نيك",
    tier: "vip",
    price: 135,
    oldPrice: 170,
    rating: 4.8,
    reviews: 145,
    description: "هاي نيك أبيض سترة رقبة عالية أنيقة. قماش فاخر، تصميم عصري يناسب جميع المناسبات.",
    images: [
      "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1578587018452-892b6fd8dbb4?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1434389677669-e08b4fcb3b5b?w=600&h=800&fit=crop"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: ["أبيض", "أسود", "رمادي"],
    badge: "VIP",
    inStock: true
  },
  {
    id: 13,
    name: "بلوفر أبيض محبوك",
    category: "بلوفر",
    tier: "premium",
    price: 110,
    oldPrice: 135,
    rating: 4.6,
    reviews: 88,
    description: "بلوفر أبيض محبوك بتفاصيل رقبة أنيقة. قماش ناعم ودافئ، تصميم كلاسيكي.",
    images: [
      "https://images.unsplash.com/photo-1578587018452-892b6fd8dbb4?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1434389677669-e08b4fcb3b5b?w=600&h=800&fit=crop"
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["أبيض", "بيج", "رمادي", "كحلي"],
    badge: "Premium",
    inStock: true
  },
  {
    id: 14,
    name: "طقم كاجوال بيج",
    category: "أطقم",
    tier: "vip",
    price: 249,
    oldPrice: 320,
    rating: 4.9,
    reviews: 67,
    description: "طقم كاجوال بيج كامل (جاكيت + بنطلون). قماش فاخر، أزرار معدنية، تصميم أنيق.",
    images: [
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1593030761757-71fae45fa0e7?w=600&h=800&fit=crop"
    ],
    sizes: ["M", "L", "XL", "XXL"],
    colors: ["بيج", "رمادي", "كحلي"],
    badge: "VIP",
    inStock: true
  },
  {
    id: 15,
    name: "بولو كتان مخطط",
    category: "بولو",
    tier: "classic",
    price: 79,
    oldPrice: null,
    rating: 4.4,
    reviews: 52,
    description: "بولو كتان مخطط أنيق بتصميم عصري. قماش كتان طبيعي، مناسب للصيف.",
    images: [
      "https://images.unsplash.com/photo-1625910513413-5fc4e5e6727e?w=600&h=800&fit=crop",
      "https://images.unsplash.com/photo-1586363104862-3a5e2ab60d8c?w=600&h=800&fit=crop"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: ["مخطط", "أبيض", "كحلي"],
    badge: null,
    inStock: true
  }
]

export const categories = [
  { id: 'all', name: 'الكل', icon: 'catalog' },
  { id: 'تيشيرتات', name: 'تيشيرتات', icon: 'tag' },
  { id: 'بولو', name: 'بولو', icon: 'bookmark' },
  { id: 'شورتات', name: 'شورتات', icon: 'folder' },
  { id: 'بناطيل', name: 'بناطيل', icon: 'folderOpen' },
  { id: 'إيسوفمان', name: 'إيسوفمان', icon: 'list' },
  { id: 'سويت شيرت', name: 'سويت شيرت', icon: 'image' },
  { id: 'فيست', name: 'فيست', icon: 'pin' },
  { id: 'هاي نيك', name: 'هاي نيك', icon: 'tag' },
  { id: 'بلوفر', name: 'بلوفر', icon: 'bookmark' },
  { id: 'أطقم', name: 'أطقم', icon: 'catalog' }
]

export const orders = [
  { id: 'ORD-001', customer: 'أحمد محمد', date: '2026-09-01', total: 267, status: 'completed', items: 3 },
  { id: 'ORD-002', customer: 'خالد العلي', date: '2026-09-01', total: 149, status: 'shipping', items: 1 },
  { id: 'ORD-003', customer: 'سعد الفهد', date: '2026-08-31', total: 445, status: 'pending', items: 4 },
  { id: 'ORD-004', customer: 'فهد السالم', date: '2026-08-30', total: 89, status: 'completed', items: 1 },
  { id: 'ORD-005', customer: 'ناصر الدوسري', date: '2026-08-29', total: 358, status: 'cancelled', items: 3 },
  { id: 'ORD-006', customer: 'عبدالله الحربي', date: '2026-08-28', total: 198, status: 'shipping', items: 2 },
]
